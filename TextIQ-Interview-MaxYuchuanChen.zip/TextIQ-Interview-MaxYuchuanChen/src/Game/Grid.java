package Game;

public class Grid {
    private int row;
    private int col;
    char theOne;
    int number;

    public Grid(int row, int col)
    {
        this.row = row;
        this.col = col;
    }

    public int row() { return row; }
    public int col() { return col; }
}
