package Game;

import java.awt.List;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Game {
	public static void updateBoard(char[][] currentBoard) {
		int currentRow = 0;
		int currentCol = 0;
		
		for (int c = currentBoard[0].length-1; c>=0; c--) {
			currentRow = currentBoard.length-1;
			for (int r = currentBoard.length-1; r>=0; r--) {
				if (currentBoard[r][c] == 'Z'+1) continue;
				currentBoard[currentRow][c] = currentBoard[r][c];
				currentRow--;
			}
			for (; currentRow>=0; currentRow--) {
				currentBoard[currentRow][c] = 'Z'+1;
			}
		}
		
		for (int r = currentBoard.length-1; r>=0; r--) {
			currentCol = 0;
			for (int c = 0; c<currentBoard[0].length; c++) {
				if (currentBoard[r][c] == 'Z'+1) continue;
				currentBoard[r][currentCol] = currentBoard[r][c];
				currentCol++;
			}
			for (; currentCol<currentBoard[0].length; currentCol++) {
				currentBoard[r][currentCol] = 'Z'+1;
			}
		}
		
	}
	
	public static Grid label(char[][] currentBoard, int[][] visited, int row, int col) {
		Queue<Grid> bfs = new LinkedList<Grid>();
		bfs.add(new Grid(row, col));
		char theOne = currentBoard[row][col];
		int count = 0;
		while (!bfs.isEmpty()) {
			Grid currentGrid = bfs.poll();
			int r = currentGrid.row();
			int c = currentGrid.col();
			currentBoard[r][c] = 'Z'+1;
			if (visited[r][c]==0) count++;
			visited[r][c] = 1;
			if (r-1 >= 0 && currentBoard[r-1][c]==theOne ) {
				bfs.add(new Grid(r-1, c));
				
			}
			if (r+1 < currentBoard.length && currentBoard[r+1][c]==theOne ) {
				bfs.add(new Grid(r+1, c));
				
			}
			if (c+1 < currentBoard[0].length && currentBoard[r][c+1]==theOne ) {
				bfs.add(new Grid(r, c+1));
				
			}
			if (c-1 >= 0 && currentBoard[r][c-1]==theOne ) {
				bfs.add(new Grid(r, c-1));
				
			}
		}
		updateBoard(currentBoard);
		Grid resultGrid = new Grid(row, col);
		resultGrid.theOne = theOne;
		resultGrid.number = count;
		return resultGrid;
	}
	
	
	
	public static void solve(Board board, ArrayList<ArrayList<Grid>> results, ArrayList<Grid> current) {
		if (board.solved()) {
			results.add(current);
			for (int i=0; i<current.size(); i++) {
				int move = i+1;
				System.out.print("Move: "+ move+ ": " + "("+current.get(i).col()+", "+ current.get(i).col()+")");
				System.out.println(" Remove " + current.get(i).theOne + " number: " + current.get(i).number);
			}
			System.exit(0);
			return;
		}
		char[][] originalBoard = board.getBoard();
		char[][] currentBoard = new char[originalBoard.length][originalBoard[0].length];
		int[][] visited = new int[originalBoard.length][originalBoard[0].length];
		
		for (int i=originalBoard.length-1; i>=0; i++) {
			for (int j=0; j<originalBoard[0].length; j++) {
				if (visited[i][j] == 1 || originalBoard[i][j] == 'Z'+1) continue;
				
				for (int a=0; a<originalBoard.length; a++) {
					for (int b=0; b<originalBoard[0].length; b++) {
						currentBoard[a][b] = originalBoard[a][b];
					}
				}
				
				Grid newGrid = label(currentBoard, visited, i, j);
				Board nextBoard = new Board(currentBoard);
				current.add(newGrid);
				solve(nextBoard, results, current);
				current.remove(current.size()-1);
				
			}
		}
		
	}

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		File file = new File("/Users/apple/Desktop/input.txt");
		Scanner sc = new Scanner(file);
		String currentString = "";
		int row = 0;
		int col = 0;
		while(sc.hasNextLine()) {
			currentString = sc.next();
			col = currentString.length();
			row++;
		}
		
		char[][] twoD_Array = new char[row][col];
		
		Scanner sc2 = new Scanner(file);
		
		int countRow = 0;
		while(sc2.hasNextLine()) {
			currentString = sc2.next();
			for (int i=0; i<currentString.length(); i++) {
				twoD_Array[countRow][i] = currentString.charAt(i);
			}
			countRow++;
		}
		
		ArrayList<ArrayList<Grid>> results = new ArrayList<ArrayList<Grid>>();
		Board myBoard = new Board(twoD_Array);
		
		ArrayList<Grid> current = new ArrayList<Grid>();
		
		solve(myBoard, results, current);
		
		if (results.size() == 0) {
			System.out.println("No result");
			return;
		}
		
		ArrayList<Grid> result = results.get(0);
		for (int i=0; i<result.size(); i++) {
			System.out.println("Move: "+i + ": " + "/("+result.get(i).row()+"/, "+ result.get(i).col()+"/)");
		}
	}

}
